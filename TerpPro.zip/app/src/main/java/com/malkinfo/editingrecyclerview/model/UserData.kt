package com.malkinfo.editingrecyclerview.model

data class UserData (
    var name:String,
    var email:String,
    var UID: String,
    var check: Boolean
//    var myPros: ArrayList<myProData>
        )
