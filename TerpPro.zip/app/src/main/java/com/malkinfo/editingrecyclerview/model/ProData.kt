package com.malkinfo.editingrecyclerview.model

import com.google.firebase.database.DataSnapshot

data class ProData(
    var proName: String,
    var proEmail: String,
    var proDescription: String
)